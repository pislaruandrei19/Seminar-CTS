interface Subscription {
    String getDescription();
    double getPrice();
}
