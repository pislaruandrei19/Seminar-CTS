package ro.ase.cts.s04;

public interface Car {
    public void setChassis(String chassis);
    public void setWheels(String wheels);
    public void setEngine(String engine);
    public void setInsideDesign(String insideDesign);
    public String showDetails();
}
