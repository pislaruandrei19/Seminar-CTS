package ro.ase.cts.s05.generic;

public interface Prototype {
    Prototype clone();
}
